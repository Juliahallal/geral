import "./styles.css";
import { useState } from "react";

export default function App() {
  // criando var de estado. no use state, está a mensagem inicial;
  const [mensa1, setMensa1] = useState("");
  const [mensa2, setMensa2] = useState("");
  // cada campo de formulário precisa de sua própria variável de estado;
  const [produto, setProduto] = useState("");
  const [preco, setPreco] = useState("");

  function verPromo(e) {
    // para evitar que, ao enviar o submit do form, ele nao limpe os formulários;
    e.preventDefault();
    // como mudar a mensagem;
    const preco3 = Number(preco) * 2.5;
    const desconto = Number(preco) * 0.5;

    setMensa1(
      `${produto} em promoção. Leve 3 por apenas R$ ${preco3.toFixed(2)}`
    );
    setMensa2(`O terceiro produto custa apenas R$ ${desconto.toFixed(2)}`);
  }

  return (
    <div>
      <h1>Supermercado Avenida</h1>

      <form onSubmit={verPromo}>
        {/* para que o programa associe esse campo de form com a 
  varialvel de estado, vou adicionar um value, onde colocarei a 
 variável entre chaves */}

        <p>
          Produto:
          <input
            type="text"
            value={produto}
            onChange={(e) => setProduto(e.target.value)}
            required
          />
        </p>

        {/* como determinamos que o conteúdo é vazio, náo vou conseguir digitar ainda. Preciso indicar que,
 toda vez que o usuário mudar o campo de formulario, vulgo digitar algo, 
vou utilizar o onChange, pra mudar o set produto
        toda vez que preicso mudar o conteudo da variável
 de um formulário, tenho que usar essa sintaxe. por fm, 
 para que ele entenda que eu quero que ele pegue oq o usuário digitar, 
 tenho que usar a sintaze e.target.value  */}
        <p>
          Preço R$:
          <input
            type="text"
            value={preco}
            onChange={(e) => setPreco(e.target.value)}
            required
          />
        </p>
        <input type="submit" value="Ver promoção" />
      </form>

      <h3>{mensa1}</h3>
      <h3>{mensa2}</h3>
    </div>
  );
}
