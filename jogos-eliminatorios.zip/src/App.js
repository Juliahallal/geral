import { useState } from "react";
import "./styles.css";

export default function App() {
  const [clube, setClube] = useState("");
  const [clubes, setClubes] = useState([]);
  const [jogos, setJogos] = useState([]);

  const listaClubes = clubes.map((clube) => <li>{clube}</li>);

  function adicionarClube(e) {
    e.preventDefault();
    // ... (operador spread - no sentido de espalhar os elementos do vetor)
    // os 3 pontinhos permite ler os elementos que ja estao em clubes
    setClubes([...clubes, clube]);
    setClube("");
    setJogos([]); // limpa o vetor de jogos, para voltar a exibir os clubes
  }

  function montarJogos() {
    if (clubes.length % 2 === 1) {
      alert("Por favor, informe uma quantidade par de clubes");
      return;
    }

    const aux = [];

    for (let i = 0; i < clubes.length; i = i + 2) {
      aux.push(clubes[i] + " x " + clubes[i + 1]);
    }
    setJogos(aux);
  }

  const listaJogos = jogos.map((jogo) => <li>{jogo}</li>);

  return (
    <div>
      <h1>Programa Controle de Jogos</h1>
      <form onSubmit={adicionarClube}>
        <p>
          Clube: &nbsp;
          <input
            type="text"
            required
            value={clube}
            onChange={(e) => setClube(e.target.value)}
          />
          &nbsp;
          <input type="submit" value="Adicionar" />
        </p>
        <p>
          <input
            type="button"
            value="Listar Clubes"
            onClick={() => setJogos([])}
          />
          &nbsp; {/*adiciona um espaco entre elementos, sem quebra de linha */}
          <input
            type="button"
            value="Montar Tabela de Jogos"
            onClick={montarJogos}
          />
        </p>
      </form>
      <ol>{listaJogos.length > 1 ? listaJogos : listaClubes}</ol>
    </div>
  );
}
