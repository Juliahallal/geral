import { useState } from "react";
import "./styles.css";

export default function App() {
  // vamos criar uma variável para cada campo de formulário

  const [nome, setNome] = useState("");
  const [nota1, setNota1] = useState("");
  const [nota2, setNota2] = useState("");
  const [media, setMedia] = useState("");
  const [aprovado, setAprovado] = useState("");
  // para alterar a cor da frase, posso utilizar outra var de estado
  const [cores, setCores] = useState("");

  function calculaMedia(e) {
    e.preventDefault();
    const calculo = (Number(nota1) + Number(nota2)) / 2;
    setMedia(`Média das notas: ${calculo.toFixed(1)}`);
    if (calculo >= 7) {
      setAprovado(`Parabéns ${nome}, você foi aprovado(a)!`);
      setCores("blue");
    } else {
      setAprovado(`Sinto muito ${nome}, você foi reprovado(a).`);
      setCores("red");
    }
  }

  return (
    <form onSubmit={calculaMedia}>
      {" "}
      {/*pode ser tanto div como form // precisamos indicar que esse form vai conter
    um evento, que vai controlar o seu submit*/}
      <h1>Programa Controle de Notas</h1>
      <p>
        Nome do Aluno:{" "}
        <input
          type="text"
          required
          value={nome}
          onChange={(e) => setNome(e.target.value)}
        />
      </p>{" "}
      {/* para atribuir que o input nome está ligado a variável nome, uso o value.
      só que, ao determinar que o input recebe a variável nome, teoricamente ela fica 
      estática, nao da pra escrever nada
      assim, preciso usar o evento 'onChange = {(e) => setNome(e.target.value)}'. essa
      sintaxe diz que, ao mudar a variável nome, ele vai jogar esse novo valor para o conteúdo nome
      através do setNome.target.value */}
      <p>
        1ª Nota:{" "}
        <input
          type="text"
          required
          value={nota1}
          onChange={(e) => setNota1(e.target.value)}
        />
      </p>
      <p>
        2ª Nota:{" "}
        <input
          type="text"
          required
          value={nota2}
          onChange={(e) => setNota2(e.target.value)}
        />
      </p>
      <input type="submit" value="Calcular" />
      {/*para apresentar as mensagens, também vou utilizar uma var de estado */}
      <h3> {media}</h3>
      <h4 style={{ color: cores }}> {aprovado}</h4>
      {/* para usar a variável cor pra alterar o texto, com o atributo, 
      vou ter que usr duas vezes as chaves, e usar o style, color e dois pontos, 
      nome da var pra cor. */}
      {/* outra forma de mudar a cor do h4, seria utilizando uma condicional 
      no próprio, sem outra variável de estado pra cor, mas mudando a variavel da cor 
      me parece mais simples*/}
    </form>
  );
}
