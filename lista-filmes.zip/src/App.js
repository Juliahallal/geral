import { useState, useEffect } from "react";
import "./styles.css";
import { filmes } from "./lista_dados.js"; //arquivo dados importado

// vamos codar utilizando mais de uma pasta: lista_dados.js
// la vamos colocar um array com dados dos filmes. pra importar
// vou colocar entre chaves a palavra filmes

export default function App() {
  const [lista, setLista] = useState([]);

  // useEffect()
  // permite executar uma funcao quando o componente e reinderizado
  // efeito no sentido de efeito colateral
  // useEffect aqui é usado pra carregar os dados na variavel de estado lista
  // sintaxe = useEffect(() => {}, [])

  useEffect(() => {
    //setLista vai receber os meus filmes
    setLista(filmes);
    //se eu quiser deixar minha lista de filmes organizada,
    // crio uma cont com o mapeamento dos elementos
    // vou criar a const tabela pra isso
  }, []);

  // tr define uma linha na tabela
  // td define cada cédula da tabela
  const tabela = lista.map((x) => (
    <tr>
      <td style={{ width: 120 }}>
        <img src={x.foto} alt="filme" className="foto" />{" "}
      </td>
      <td>
        <b>{x.titulo}</b> <br />
        Gênero: {x.genero} <br />
        Duração: {x.duracao} min
      </td>
    </tr>
  ));

  //o x vai representar cada item da lista
  return (
    <div>
      <h1>Lista de Filmes</h1>
      {/* <table style={{ border: 1, borderColor: "black" }}>{tabela}</table>
essa tabela nao ficou como o professor gostaria, entao ele adicionou 
o bootstrap na pagina. para isso, copiamos o link de css do bootstrap
e adicionamos no index.html, q esta na pasta public
    */}
      <table className="table">{tabela}</table>
    </div>
  );
}
