export const filmes = [
  {
    titulo: "Shazam! Fúria dos Deuses",
    genero: "Ação",
    duracao: 130,
    foto:
      "https://www.cineflix.com.br/wp-content/uploads/2023/03/shazam2-189x278.jpg"
  },
  {
    titulo: "A Baleia",
    genero: "Drama",
    duracao: 117,
    foto:
      "https://www.cineflix.com.br/wp-content/uploads/2023/02/a-baleia-189x278.jpg"
  },
  {
    titulo: "John Wick 4: Baba Yaga",
    genero: "Ação",
    duracao: 170,
    foto:
      "https://www.cineflix.com.br/wp-content/uploads/2023/03/john-wick-189x278.jpg"
  },
  {
    titulo: "Gato de Botas 2: O Último Pedido",
    genero: "Animação",
    duracao: 112,
    foto:
      "https://www.cineflix.com.br/wp-content/uploads/2022/03/gato_de_botas_2-189x278.png"
  }
];
